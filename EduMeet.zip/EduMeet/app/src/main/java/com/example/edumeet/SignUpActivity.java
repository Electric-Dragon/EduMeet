package com.example.edumeet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    int RC_SIGN_IN = 1;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getSupportActionBar().hide();

        final GoogleSignInClient googleSignInClient;
        final EditText etEmail = findViewById(R.id.etEmail);
        final EditText etPassword = findViewById(R.id.etPassword);
        final EditText etName = findViewById(R.id.etName);
        final EditText etMajor = findViewById(R.id.etMajor);
        Button btnSignUp = findViewById(R.id.btnSignUp);

        TextView textView = findViewById(R.id.textView5);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            }
        });

        SignInButton signInButton = findViewById(R.id.btnGoogleSignIn);
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText etMajor = findViewById(R.id.etMajor2);
                String major = etMajor.getText().toString();

                if (major.isEmpty()) {
                    etMajor.setError("Enter your major");
                    etMajor.requestFocus();
                } else {

                Intent signInIntent = googleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);

                }

            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final ProgressBar progressBar = findViewById(R.id.progressBar);
                progressBar.setVisibility(View.VISIBLE);

                final String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                final String fullname = etName.getText().toString();
                final String major = etMajor.getText().toString();

                if (email.isEmpty()) {
                    etEmail.setError("Enter your email!");
                    etEmail.requestFocus();
                    progressBar.setVisibility(View.GONE);
                } else if (password.isEmpty()) {
                    etPassword.setError("Enter your password!");
                    etPassword.requestFocus();
                    progressBar.setVisibility(View.GONE);
                } else if (fullname.isEmpty()) {
                    etName.setError("Enter your name!");
                    etName.requestFocus();
                    progressBar.setVisibility(View.GONE);
                } else if (major.isEmpty()) {
                    etMajor.setError("Enter your major!");
                    etMajor.requestFocus();
                    progressBar.setVisibility(View.GONE);
                } else if (!(email.isEmpty() && password.isEmpty() && fullname.isEmpty() && major.isEmpty())) {
                    firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                FirebaseFirestore db = FirebaseFirestore.getInstance();

                                Map <String, Object> user = new HashMap<>();
                                user.put("name", fullname);
                                user.put("major", major);

                                db.collection("Users").document(firebaseAuth.getCurrentUser().getUid()).set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful()) {
                                            firebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Toast.makeText(SignUpActivity.this, "Successfully Registered, check your email to verify your account", Toast.LENGTH_LONG).show();
                                                    firebaseAuth.signOut();
                                                    startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                                }
                                            });
                                        }

                                    }
                                });

                            } else if (!(task.isSuccessful())) {
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(SignUpActivity.this, "Error, " + task.getException().toString(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }

    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount acc = completedTask.getResult(ApiException.class);
            FirebaseGoogleAuth(acc);
        } catch (ApiException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private void FirebaseGoogleAuth(GoogleSignInAccount acc) {

        EditText etMajor = findViewById(R.id.etMajor2);
        final ProgressBar progressBar = findViewById(R.id.progressBar);
        final String name = acc.getGivenName() + " " + acc.getFamilyName();
        final String major = etMajor.getText().toString();

        progressBar.setVisibility(View.VISIBLE);

        AuthCredential authCredential = GoogleAuthProvider.getCredential(acc.getIdToken(), null);
        firebaseAuth.signInWithCredential(authCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    FirebaseFirestore db = FirebaseFirestore.getInstance();

                    Map <String, Object> user = new HashMap<>();
                    user.put("name", name);
                    user.put("major", major);

                    db.collection("Users").document(firebaseAuth.getCurrentUser().getUid()).set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if (task.isSuccessful()) {

                                Toast.makeText(SignUpActivity.this, "Successfully Registered", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(SignUpActivity.this, UserActivity.class));
                                finish();
                            }

                        }
                    });

                } else if (!(task.isSuccessful())) {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(SignUpActivity.this, "Error, " + task.getException().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }

}