package com.example.edumeet;

public class ChatData {

    public String uid,message,name;

    public ChatData(String uid, String message, String name) {
        this.uid = uid;
        this.message = message;
        this.name = name;
    }

}
