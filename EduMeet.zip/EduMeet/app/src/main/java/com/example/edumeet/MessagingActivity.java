package com.example.edumeet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessagingActivity extends AppCompatActivity {

    String otherUID;
    String UID;
    String name;
    String message;
    EditText etMessage;
    ListView messagesList;
    Button btnSend;
    FirebaseFirestore db;
    DatabaseReference dbRef1,dbRef2;
    List<String> names = new ArrayList<>();
    List<String> uids = new ArrayList<>();
    List<String> messages = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging);

        getSupportActionBar().hide();

        messagesList = findViewById(R.id.messagesList);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        UID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db = FirebaseFirestore.getInstance();

        db.collection("Users").document(UID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();
                    Map<String, Object> user = new HashMap<>();
                    user = documentSnapshot.getData();
                    name = user.get("name").toString();
                }
            }
        });

        Intent intent = getIntent();
        otherUID = intent.getStringExtra("uid");

        dbRef1 = FirebaseDatabase.getInstance().getReference("Chats/" + UID + "/" + otherUID);
        dbRef2 = FirebaseDatabase.getInstance().getReference("Chats/" + otherUID + "/" + UID);
        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("ChatRooms/" + UID + "/" + otherUID);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                message = etMessage.getText().toString();
                if (message.isEmpty()) {
                    Toast.makeText(MessagingActivity.this, "Enter something!", Toast.LENGTH_SHORT).show();
                } else {
                    final ChatData newChat = new ChatData(UID, message, name);
                    final String pushID = dbRef1.push().getKey();
                    dbRef1.child(pushID).setValue(newChat).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            etMessage.setText("");
                            dbRef2.child(pushID).setValue(newChat);
                            ChatRoomInfo newInfo = new ChatRoomInfo(otherUID);
                            databaseReference.setValue(newInfo);

                        }
                    });
                }
            }
        });

        dbRef1.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                dbRef1.child(snapshot.getKey() + "/message").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        messages.add(snapshot.getValue().toString());
                        arrayAdapter = new ArrayAdapter<String>(MessagingActivity.this, android.R.layout.simple_list_item_1, messages);
                        arrayAdapter.notifyDataSetChanged();
                        messagesList.setAdapter(arrayAdapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}