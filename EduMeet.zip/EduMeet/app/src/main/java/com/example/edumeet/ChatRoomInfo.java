package com.example.edumeet;

public class ChatRoomInfo {

    public String uid;
    public ChatRoomInfo(String uid) {
        this.uid = uid;
    }

}
